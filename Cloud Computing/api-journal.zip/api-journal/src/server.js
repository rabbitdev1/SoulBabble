require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const postJournalRouter = require('./routes/postJournal');
const getJournalRouter = require('./routes/getJournal');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(bodyParser.json());

app.use('/journal/post', postJournalRouter);
app.use('/journal/get', getJournalRouter);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
