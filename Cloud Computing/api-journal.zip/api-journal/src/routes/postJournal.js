const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const dotenv = require('dotenv');

dotenv.config();

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

// Check database connection
db.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
  } else {
    console.log('Connected to database');
  }
});

router.post('/', (req, res) => {
  const { user_id, username, message } = req.body;

  // Perform validation and store journaling data in the community table
  const sql = `
    INSERT INTO community (user_id, username, message, timestamp)
    VALUES (?, ?, ?, CURRENT_TIMESTAMP())
  `;

  db.query(sql, [user_id, username, message], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    } else {
      res.status(200).send('Journal posted successfully');
    }
  });
});

module.exports = router;
