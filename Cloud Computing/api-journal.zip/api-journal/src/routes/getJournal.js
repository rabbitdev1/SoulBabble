const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const dotenv = require('dotenv');

dotenv.config();

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

router.get('/', (req, res) => {
  const { username } = req.query;

  // Ambil data journaling dari tabel community dengan menggunakan prepared statement
  const sql = `
    SELECT * FROM community WHERE username = ?
  `;

  db.query(sql, [username], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    } else {
      if (result.length === 0) {
        res.status(404).send('No data found for the specified username');
      } else {
        res.status(200).json(result);
      }
    }
  });
});

module.exports = router;
